package ej202;

public class Main {
    public static void main(String[] args) {
        CrearBaseDatos.main(args);
        CrearTabla.main(args);
        CompletaLibros.main(args);
        ConsultaLibros.main(args);
        ModificacionLibros.main(args);
        LimpiarTabla.main(args);
    }

}
