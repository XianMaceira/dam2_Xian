package ej203;

public class Main {
    public static void main(String[] args) {
        CrearBaseDatos.main(args);
        CrearTabla.main(args);
        CompletaTareas.main(args);
        ConsultaTareas.main(args);
        ModificaTareas.main(args);
        LimpiarTabla.main(args);
    }
}
