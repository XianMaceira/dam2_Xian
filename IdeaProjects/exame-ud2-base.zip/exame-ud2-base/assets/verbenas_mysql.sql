CREATE TABLE IF NOT EXISTS `verbenas` (
  `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `lugar` varchar(100) NOT NULL,
  `data` date NOT NULL,
  `orquesta` varchar(100) NOT NULL
);

