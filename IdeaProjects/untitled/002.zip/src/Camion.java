public class Camion extends Vehiculo{

    private int ejes;



    public Camion(String color, int ruedas, int potencia, int cilindrada, int ejes) {
        super(color, ruedas, potencia, cilindrada);
        this.ejes = ejes;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Pasajeros"+this.ejes+"\n");
        return super.toString() + sb.toString();
    }
}
