package Ejercicio5;

public interface CentroEstudios extends CalculosCentroEstudios, DatosCentroEstudios {

}
