/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.manageSalonPalace;

import view.managesalonPalace.ManageSalonPalaceJDialog;

/**
 *
 * @author maceira_barca_xian
 */
public class ManageSalonPalaceController {
    private final ManageSalonPalaceJDialog view;
    
    public ManageSalonPalaceController(ManageSalonPalaceJDialog view) {
        this.view = view;
    }
}
