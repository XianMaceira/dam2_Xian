package clock;

import java.util.EventObject;

/**
 * La clase{@code AlarmEvent} representa un EventObject para los eventos de alarmas.
 * It extends {@code EventObject} to encapsulate the source of the event.
 * 
 * @author maceira_barca_xian
 * @version 1.0
 */
public class AlarmEvent extends EventObject {

    
    /**
     * Construye un nuevo {@code AlarmEvent} con el source especificado
     * 
     * @param source Es el objeto que genera el evento
     */
    public AlarmEvent(Object source) {
        super(source);
    }

}
