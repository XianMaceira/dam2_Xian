/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 */
package clock;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.util.Calendar;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.Timer;


/**
 * ClockBean es un componente JavaBean que representa una visualización del reloj.
 * Extiende JLabel e implementa las interfaces ActionListener y Serializable.
 * El reloj se puede mostrar en modo de 24 horas o en modo de 12 horas con AM/PM.
 * También admite una función de alarma que activa un evento cuando se alcanza el tiempo establecido.
 * 
 * @author maceira_barca_xian
 * @version 1.0
 */


public class ClockBean extends JLabel implements ActionListener, Serializable {

    /**
     * Determina si se usara el modo 24 o 12 horas
     */
    public boolean mode24;
    
    /**
     * Indica si la funcion de alarma está activada
     */
    public boolean enableAlarm;
    
    /**
     * Determina los minutos para la alarma
     */
    public int minutesAlarm;
    
    /**
     * Determina las horas para la alarma
     */
    public int hourAlarm;
    
    private final Timer t;
    private Calendar calendar;
    private IAlarmListener receptor;
    private String message;
    private final String[] hours = {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"};
    private final String[] minutes = {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"};
    private final String[] seconds = {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"};
    private final String[] AMPM = {"AM", "PM"};
    
    /**
     * Método para recibir el mensaje de la alarma
     * 
     * @return Devuelve el mensaje para la alarma
     */
    public String getMessage() {
        return message;
    }

    /**
     * Método para establecer el mensaje de la alarma
     * 
     * @param message Recibe una cadena, la cual será el mensaje
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Método para comprobar si la alarma esta activada
     * 
     * @return Devuelve un booleano true si la alarma esta activada, false si no lo está.
     */
    public boolean isEnableAlarm() {
        return enableAlarm;
    }

    /**
     * Método para activar la alarma
     * 
     * @param enableAlarm Recibe un booleano true para activar la alarma, falso para desactivarla
     */
    public void setEnableAlarm(boolean enableAlarm) {
        this.enableAlarm = enableAlarm;
    }

    /**
     * Método para obtener los minutos de la alarma
     * 
     * @return Devuelve la hora de la alarma en forma de entero
     */
    public int getMinutesAlarm() {
        return minutesAlarm;
    }

    /**
     * Método para establecer los minutos de la alarma
     * 
     * @param minutesAlarm Recibe un parametro en forma de entero que serán los minutos de la alarma
     */
    public void setMinutesAlarm(int minutesAlarm) {
        this.minutesAlarm = minutesAlarm;
    }

    /**
     * Método para obtener la hora de la alarma
     * 
     * @return Devuleve la hora de la alarma en forma de entero
     */
    public int getHourAlarm() {
        return hourAlarm;
    }

    /**
     * Método para establecer un alarma
     * 
     * @param hourAlarm Se introduce un parametro entero el cual tiene que ser la hora a la que se establece la alarma
     */
    public void setHourAlarm(int hourAlarm) {
        this.hourAlarm = hourAlarm;
    }

    /**
     * Método para comprobar si el reloj esta en formato 24h
     * 
     * @return Devuelve true si el modo es de 24 horas
     */
    public boolean isMode24() {
        return mode24;
    }

    /**
     * Método para establecer el formato del rejoj (12 o 24 horas)
     * 
     * @param mode24 Recibe un booleano true si se quiere usar el modo 24h, falso para el de 12h
     */
    public void setMode24(boolean mode24) {
        this.mode24 = mode24;
    }

    /**
     * Construye una instancia de ClockBean. Inicializa el display, pone el modo 24h como default e inicia un timer para actualizar el reloj cada segundo.
     */
    
    public ClockBean() {
        this.setHorizontalAlignment(SwingConstants.RIGHT);
        message = "";
        mode24 = true;
        enableAlarm = false;
        t = new Timer(1000, this);
        t.start();
        calendar = Calendar.getInstance();

        String h = hours[calendar.get(Calendar.HOUR_OF_DAY)];
        String m = minutes[calendar.get(Calendar.MINUTE)];
        String s = seconds[calendar.get(Calendar.SECOND)];
        String AM_PM = AMPM[calendar.get(Calendar.AM_PM)];
        setText(h + ":" + m + ":" + s + " " + AM_PM);
    }

     /**
     * Actualiza el reloj cada segundo y comprueba si la alarma está activada.
     *
     * @param e The ActionEvent triggering the update.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        String h;
        String m;
        String s;
        String AM_PM;
        calendar = Calendar.getInstance();

        if (isMode24()) {
            h = hours[calendar.get(Calendar.HOUR_OF_DAY)];
            m = minutes[calendar.get(Calendar.MINUTE)];
            s = seconds[calendar.get(Calendar.SECOND)];
            setText(h + ":" + m + ":" + s);
        } else {
            h = hours[calendar.get(Calendar.HOUR)];
            m = minutes[calendar.get(Calendar.MINUTE)];
            s = seconds[calendar.get(Calendar.SECOND)];
            AM_PM = AMPM[calendar.get(Calendar.AM_PM)];
            setText(h + ":" + m + ":" + s + " " + AM_PM);
        }
        repaint();

        if (enableAlarm) {
            if ((Integer.parseInt(h) == hourAlarm) && (Integer.parseInt(m) == minutesAlarm)) {
                receptor.captureAlarm(new AlarmEvent(this));
            }
        }
    }

    /**
     * Método que añade un IAlarmListener 
     * 
     * @param receptor Recibe el IAlarmListener que se va a añadir.
     */
    public void addAlarmListener(IAlarmListener receptor) {
        this.receptor = receptor;
    }

    /**
     * Método que borra un IAlarmListener
     * 
     * @param receptor Recibe el parametro del IAlarmListener que se desea borrar.
     */
    public void removeAlarmListener(IAlarmListener receptor) {
        this.receptor = null;
    }
}
