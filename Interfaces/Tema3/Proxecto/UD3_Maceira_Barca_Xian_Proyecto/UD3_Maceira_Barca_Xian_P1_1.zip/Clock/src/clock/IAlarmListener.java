/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package clock;

import java.util.EventListener;


/**
 * La interfaz {@code IAlarmListener} representa un detector de eventos de alarma.
 * Las clases que implementan esta interfaz pueden capturar y responder a eventos de alarma.
 * Implementa la interfaz de {@code EventListener}
 * 
 * @author maceira_barca_xian
 * @version 1.0
 */
public interface IAlarmListener extends EventListener {

    /**
     * Se invoca cuando un evento de la alarma es capturado
     * @param ev Representa el evento de la alarma capturado
     */
    public void captureAlarm(AlarmEvent ev);
}
