/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import clock.AlarmEvent;
import clock.IAlarmListener;
import controller.ManageAldData.ManageAldDataController;
import controller.notificationsController.NotificationsController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.aldComputerService.AldComputerService;
import view.MainJFrame;
import view.aldComputerService.ManageAldDataDialog;
import view.notifications.NotificationsJDialog;

/**
 *
 * @author dides
 */
public class FrontControllerJFrame {

    private final NotificationsJDialog notificationsview;
    private final MainJFrame view;
    private final AldComputerService model;


    public FrontControllerJFrame(MainJFrame view, AldComputerService model, NotificationsJDialog notificationsview) {
        this.view = view;
        this.model = model;
        this.notificationsview = notificationsview;
        this.view.setQuitMenuItemListener(this.setQuitMenuItemActionListener());
        this.view.setManageDataMenuItemListener(setManageDataMenuItemActionListener());
        this.view.setNotificationsMenuItemListener(setNotificationsMenuItemActionListener());
        this.view.addAlarmListener(this.setClockBeanAlarmListener());

    }

    private ActionListener setQuitMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
                System.exit(0);
            }
        };
        return al;
    }
    
    private ActionListener setManageDataMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ManageAldDataDialog madd = new ManageAldDataDialog(view, true);
                ManageAldDataController maddc = new ManageAldDataController(madd, model);
                madd.setVisible(true);
            }
        };
        return al;
    }
    
    private ActionListener setNotificationsMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                NotificationsJDialog nd = new NotificationsJDialog(view, true);
                NotificationsController nc = new NotificationsController(view, nd);
                nd.setVisible(true);
            }
        };
        return al;
    }
    
    private IAlarmListener setClockBeanAlarmListener() {
        IAlarmListener listener = new IAlarmListener() {
            @Override
            public void captureAlarm(AlarmEvent ev) {
                view.setEnableAlarm(false);
                view.removeAlarm(this);
                JOptionPane.showMessageDialog(view, view.getAlarmMessage(),
                        "Message", JOptionPane.INFORMATION_MESSAGE);
            }
        };
        return listener;
    }
    
    
  
}
