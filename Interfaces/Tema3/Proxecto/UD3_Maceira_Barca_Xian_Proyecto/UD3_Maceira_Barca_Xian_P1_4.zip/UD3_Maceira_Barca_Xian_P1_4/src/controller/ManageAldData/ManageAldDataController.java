/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.ManageAldData;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.aldComputerService.AldComputerService;
import view.aldComputerService.ManageAldDataDialog;

/**
 *
 * @author maceira_barca_xian
 */
public class ManageAldDataController {

    private final ManageAldDataDialog view;
    private final AldComputerService model;

    public ManageAldDataController(ManageAldDataDialog view, AldComputerService model) {
        this.view = view;
        this.model = model;
        setListeners();
        

    }

    private ActionListener setCancelButtonListener() {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
            }
        };
    }

    private ActionListener setEditButtonListener() {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        };
    }

    private ActionListener setSaveButtonListener() {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setName(view.getNameTextField());
                model.setAddress(view.getAddressTextField());
                model.setPhone(view.getPhoneTextField());
                model.setEmployees(view.getEmployeesSpinnerValue());
                
            }
        };
    }
    
   

    private void setListeners() {
        this.view.setCancelButtonActionListener(setCancelButtonListener());
        this.view.setEditButtonActionListener(setEditButtonListener());
        this.view.setSaveButtonActionListener(setSaveButtonListener());

    }

}
