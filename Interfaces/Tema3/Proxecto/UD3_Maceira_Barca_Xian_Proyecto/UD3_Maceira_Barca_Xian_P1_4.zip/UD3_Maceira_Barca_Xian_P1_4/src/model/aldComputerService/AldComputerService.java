/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.aldComputerService;

import view.aldComputerService.ManageAldDataDialog;

/**
 *
 * @author maceira_barca_xian
 */
public class AldComputerService {
    
    private ManageAldDataDialog view;
    
    private String name;
    private String address;
    private String phone;
    private String employees;

    public AldComputerService() {
        
    }
    
    public AldComputerService(String name, String address, String phone, String employees) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.employees = employees;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String adress) {
        this.address = adress;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmployees() {
        return employees;
    }

    public void setEmployees(String employees) {
        this.employees = employees;
    }
    
    
}
