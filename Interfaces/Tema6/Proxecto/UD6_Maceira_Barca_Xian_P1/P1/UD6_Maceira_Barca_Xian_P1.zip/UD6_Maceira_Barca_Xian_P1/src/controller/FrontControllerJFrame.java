/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import clock.AlarmEvent;
import clock.IAlarmListener;
import controller.GenerateReport.GenerateReportController;
import controller.ManageAldData.ManageAldDataController;
import controller.manageAldComputers.ManageAldComputersController;
import controller.notificationsController.NotificationsController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicOptionPaneUI;
import javax.swing.plaf.basic.BasicOptionPaneUI.ButtonActionListener;
import model.aldComputerService.AldComputerService;
import view.MainJFrame;
import view.aldComputerService.ManageAldDataDialog;
import view.aldComputers.ManageAldComputerDialog;
import view.notifications.NotificationsJDialog;
import view.report.GenerateReportJDialog;

/**
 *
 * @author dides
 */
public class FrontControllerJFrame {

    private final NotificationsJDialog notificationsview;
    private final MainJFrame view;
    private final AldComputerService model;



    public FrontControllerJFrame(MainJFrame view, AldComputerService model, NotificationsJDialog notificationsview /*GenerateReportJDialog reportview*/) {
        this.view = view;
        this.model = model;
        
        this.view.setQuitMenuItemListener(this.setQuitMenuItemActionListener());
        this.view.setManageDataMenuItemListener(this.setManageDataMenuItemActionListener());
        this.view.setManageComputerMenuItemListener( this.setComputerMenuItemActionListener());
        this.view.setNotificationsMenuItemListener(this.setNotificationsMenuItemActionListener());
        this.view.setReportMenuItemListener(this.setReportMenuItemActionListener());
        
        this.notificationsview = notificationsview;
        this.view.addAlarmListener(setClockBeanAlarmListener());
        
       
    }

    private ActionListener setQuitMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
                System.exit(0);
            }
        };
        return al;
    }
    
    private ActionListener setManageDataMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ManageAldDataDialog madd = new ManageAldDataDialog(view, true);
                ManageAldDataController maddc = new ManageAldDataController(madd, model);
                madd.setVisible(true);
            }
        };
        return al;
    }
    
    private ActionListener setNotificationsMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                NotificationsJDialog nd = new NotificationsJDialog(view, true);
                NotificationsController nc = new NotificationsController(view, nd);
                nd.setVisible(true);
            }
        };
        return al;
    }
    
    private ActionListener setComputerMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ManageAldComputerDialog macd = new ManageAldComputerDialog(view, true);
                ManageAldComputersController macc = new ManageAldComputersController(macd, model);
                macd.setVisible(true);
            }
        };
        return al;
    }
    
   
    
   private IAlarmListener setClockBeanAlarmListener() {
        IAlarmListener listener = new IAlarmListener() {
            @Override
            public void captureAlarm(AlarmEvent ev) {
                view.setEnableAlarm(false);
                view.removeAlarm(this);
                JOptionPane.showMessageDialog(view, view.getAlarmMessage(),
                        "Message", JOptionPane.INFORMATION_MESSAGE);
            }
        };
        return listener;
    }
    
    
    private ActionListener setReportMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GenerateReportJDialog grd= new GenerateReportJDialog(view, true);
                GenerateReportController grdc = new GenerateReportController(grd);
                grd.setVisible(true);
            }
        };
        return al;
    }
    
    
}
