/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.GenerateReport;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import view.report.GenerateReportJDialog;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;


/**
 *
 * @author maceira_barca_xian
 */
public class GenerateReportController {
    
    static Connection conn = null;
    static String currentDirectory = System.getProperty("user.dir");


    private final GenerateReportJDialog view;

    public GenerateReportController(GenerateReportJDialog view) {
        this.view = view;
        setListeners();
    }

    private ActionListener setAutoFillButtonListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.getDatabaseTextField().setText("aldComputerService");
                view.getPortTextField().setText("3306");
                view.getUsernameTextField().setText("user");
                view.getPasswordTextField().setText("abc123.");
                view.getipTextField().setText("192.168.250.2");
            }
        };
        return al;
    }

    private ActionListener setImportButtonListener() {
        ActionListener al;
        al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String server = view.getipTextField().getText();
                String port = view.getPortTextField().getText();
                String database = view.getDatabaseTextField().getText();
                String username = view.getUsernameTextField().getText();
                String password = view.getPasswordTextField().getText();
                
        
                JFileChooser fc = new JFileChooser("./Reports");
                fc.setDialogTitle("Select directory");
                fc.setSelectedFile(new File("Report_5_5.pdf"));
                
                int selection = fc.showSaveDialog(view);
                
                if(selection == JFileChooser.APPROVE_OPTION) {
                    File defaultFile = fc.getSelectedFile();
                    
                    try {
                    conn = DriverManager.getConnection("jdbc:mariadb://" + server + ":" + port + "/" + database, username, password);
                    conn.setAutoCommit(false);
                    fc.setCurrentDirectory(defaultFile);
                    JasperReport report = JasperCompileManager.compileReport(this.getClass().getClassLoader().getResourceAsStream("resources/Report_5_4.jrxml"));
                    JasperPrint print = JasperFillManager.fillReport(report, null, conn);
                    JasperExportManager.exportReportToPdfFile(print, defaultFile.getAbsolutePath());
                    JasperViewer.viewReport(print, false);
                } catch (SQLException error) {
                    System.out.println("Connection error: " + error.getMessage());
                } catch (JRException ex) {
                    Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
                } finally {
                    try {
                        if (conn != null && !conn.isClosed()) {
                            conn.close();
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(GenerateReportController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                }
                
                
                

            }
        };
        return al;
    }

    private ActionListener setCancelButtonListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
            }
        };
        return al;
    }

    private void setListeners() {
        this.view.setAutoFillButtonActionListener(setAutoFillButtonListener());
        this.view.setImportButtonActionListener(setImportButtonListener());
        this.view.setCancelButtonActionListener(setCancelButtonListener());
    }

}
