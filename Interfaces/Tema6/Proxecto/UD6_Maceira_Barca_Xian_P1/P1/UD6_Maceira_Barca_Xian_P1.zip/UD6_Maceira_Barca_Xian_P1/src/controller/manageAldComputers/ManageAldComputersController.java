/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.manageAldComputers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import model.aldComputerService.AldComputerService;
import model.aldComputerService.Computer;
import model.aldComputerService.ComputerType;
import view.aldComputers.ManageAldComputerDialog;

/**
 *
 * @author maceira_barca_xian
 */
public class ManageAldComputersController {
    
    private final ManageAldComputerDialog view;
    private final AldComputerService model;

    public ManageAldComputersController(ManageAldComputerDialog view, AldComputerService model) {
        this.view = view;
        this.model = model;
        
        this.disableFields();
        this.addDefaultComputersToTable();
        this.view.getComputerTable().getSelectionModel().addListSelectionListener(this.getListSelectionListener());
        this.view.addButtonActionListener(this.getAddButtonActionListener());
        this.view.addTableModelListener(this.getTableModelListener());
        this.view.addCancelButtonActionListener(this.getCancelButtonActionListener());
        this.view.addSaveButtonActionListener(this.getSaveButtonActionListener());
        this.view.addEditButtonActionListener(this.getEditButtonActionListener());
        this.view.addNewComputerButtonActionListener(this.getNewComputerButtonActionListener());
        this.view.addDeleteButtonActionListener(this.getDeleteButtonActionListener());
        this.view.changeComboBoxModel(this.fillComboBoxItems());
        
    }
    
    private void disableFields() {
        this.view.enableTextFields(false);
        this.view.enableCombobox(false);
    }
    
    
    private TableModelListener getTableModelListener() {
        TableModelListener tl = new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent tme) {
                if (tme.getType() == TableModelEvent.UPDATE) {
                    int row = tme.getFirstRow();
                    int col = tme.getColumn();
                    String data = view.getComputerTableCellInfo(row, col);
                }
            }
        };
        return tl;
    }
    
    private ActionListener getAddButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.setSerialTextField("");
                view.setBrandTextField("");
                view.setModelTextField("");
                view.enableCombobox(true);
                view.enableTextFields(true);
                view.setVisibleCancelComputerButton(true);
                view.setVisibleSaveComputerButton(false);
                view.setVisibleAddComputerButton(true);
            }
            
        };
        return al;
    }
    
    
    
     private ActionListener getCancelButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.setSerialTextField("");
                view.setBrandTextField("");
                view.setModelTextField("");
                view.enableTextFields(false);
                view.enableCombobox(false);

                view.setVisibleAddComputerButton(false);
                view.setVisibleCancelComputerButton(false);
                view.setVisibleSaveComputerButton(false);
            }
        };
        return al;
    }
     
     private ActionListener getSaveButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String serial = view.getSerialTextField().getText();
                String brand = view.getBrandTextField().getText();
                String model = view.getModelTextField().getText();


                int selectedRow = view.getComputerTable().getSelectedRow();

                if (selectedRow != -1) {

                    view.editTableRow(selectedRow, serial, brand, model);
                }
                view.setVisibleAddComputerButton(false);
                view.setVisibleCancelComputerButton(false);
                view.setVisibleSaveComputerButton(false);
                
                view.enableTextFields(false);
                view.enableCombobox(false); 
            }
        };
        return al;
    }
     
    private ActionListener getEditButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                view.enableCombobox(true);
                view.enableTextFields(true);

                view.setVisibleAddComputerButton(false);
                view.setVisibleCancelComputerButton(true);
                view.setVisibleSaveComputerButton(true);
            }
        };
        return al;
    }
    
    private void addDefaultComputersToTable(){
        for(Computer c : model.getComputers()){
            this.addNewComputer(c);
        }
    }
     
    
    private void addNewComputer(Computer computer){
        DefaultTableModel tm = (DefaultTableModel) this.view.getComputersTableModel();
        Object[] computerData = new Object[]{
            computer.getSerialNumber(),computer.getBrand(), computer.getModel()
        };
        tm.addRow(computerData);
        
        this.view.addComputersTableModel(tm);
        
    } 
    
   private ListSelectionListener getListSelectionListener() {
        ListSelectionListener listener = new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = view.getComputerTable().getSelectedRow();
                    if (selectedRow != -1) {

                        String serial = view.getComputerTableCellInfo(selectedRow, 0);
                        Computer c = model.getSelectedComputers(serial);
                        String brand = view.getComputerTableCellInfo(selectedRow, 1);
                        String model = view.getComputerTableCellInfo(selectedRow, 2);

                        view.selectInComboBox(c.getType().ordinal());
                        view.setSerialTextField(serial);
                        view.setBrandTextField(brand);
                        view.setModelTextField(model);
                    }
                }
            }
        };
        return listener;
    }
   
   public DefaultComboBoxModel<String> fillComboBoxItems() {
        DefaultComboBoxModel<String> dcmbm = new DefaultComboBoxModel<>();
        for (ComputerType c : ComputerType.values()) {
            dcmbm.addElement(c.toString());
        }
        return dcmbm;
    }
   
   private void addRowToTable(String serial, String brand, String model) {
        DefaultTableModel tm = (DefaultTableModel) view.getComputersTableModel();
        Object[] data = new Object[]{serial, brand, model};
        tm.addRow(data);
    }
   
   private ActionListener getNewComputerButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String serial = view.getSerialTextField().getText();
                String brand = view.getBrandTextField().getText();
                String model = view.getModelTextField().getText();

                addRowToTable(serial, brand, model);
                
                view.setSerialTextField("");
                view.setBrandTextField("");
                view.setModelTextField("");
                view.enableTextFields(false);
                view.enableCombobox(false);
                view.setVisibleCancelComputerButton(false);
                view.setVisibleSaveComputerButton(false);
                view.setVisibleAddComputerButton(false);
            }
        };
        return al;
    }
   
    private void deleteSelectedRow(int row) {
        DefaultTableModel tm = (DefaultTableModel) view.getComputersTableModel();
        tm.removeRow(row);
    }
   
   private ActionListener getDeleteButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = view.getComputerTable().getSelectedRow();
                if (row != -1) {
                    deleteSelectedRow(row);
                }

            }

        };
        return al;
    }
    
}
