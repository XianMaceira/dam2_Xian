/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import controller.FrontControllerJFrame;
import model.aldComputerService.AldComputerService;
import view.MainJFrame;
import view.notifications.NotificationsJDialog;
import view.report.GenerateReportJDialog;


/**
 *
 * @author dides
 */
public class Main {

    public static void main(String[] args) {
        MainJFrame mainview=new MainJFrame();
        NotificationsJDialog nview = new NotificationsJDialog(mainview, true);
        GenerateReportJDialog rview = new GenerateReportJDialog(mainview, true);
        AldComputerService model = new AldComputerService();
        FrontControllerJFrame fc=new FrontControllerJFrame(mainview, model, nview);
        mainview.setVisible(true);
        
    }
}
