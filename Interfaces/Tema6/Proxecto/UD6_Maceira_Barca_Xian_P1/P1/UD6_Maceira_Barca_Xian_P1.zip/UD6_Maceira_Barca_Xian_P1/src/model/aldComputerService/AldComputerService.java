/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.aldComputerService;

import java.util.Collection;
import java.util.HashMap;

/**
 *
 * @author maceira_barca_xian
 */
public class AldComputerService {
    
    private String name;
    private String address;
    private String phone;
    private int employees;
    private final HashMap<String, Computer> computers= new HashMap<>();
    
    
    
    /*public AldComputerService(String name, String address, String phone, String employees) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.employees = employees;
    }*/
    
    public AldComputerService() {
        this.name = "";
        this.address = "";
        this.phone = "";
        this.employees = 0;
        addDefaultComputers();
    }
    
    public void addDefaultComputers() {
        Laptop lp = new Laptop("2F345465", "Omen", "17k", ComputerType.Laptop, "17", "No");
        Server sv = new Server("m23k345", "Dell", "PowerEdge",ComputerType.Server, "42U", "200");
        PersonalComputer pc = new PersonalComputer("ez343654", "Epical-Q", "Oac-9", ComputerType.Personal, "16", "953");
        computers.put(lp.getSerialNumber(), lp);
        computers.put(pc.getSerialNumber(), pc);
        computers.put(sv.getSerialNumber(), sv);
    }
    
    public Collection<Computer> getComputers(){
        return computers.values();
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String adress) {
        this.address = adress;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getEmployees() {
        return employees;
    }

    public void setEmployees(int employees) {
        this.employees = employees;
    }
    
    public Computer getSelectedComputers(String serial){
        return computers.get(serial);
        
    }
    
    
}
