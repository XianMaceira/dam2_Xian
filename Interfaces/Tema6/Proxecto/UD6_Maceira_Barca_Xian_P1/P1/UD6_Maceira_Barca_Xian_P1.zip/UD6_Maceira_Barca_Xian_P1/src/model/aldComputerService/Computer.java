/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.aldComputerService;

/**
 *
 * @author maceira_barca_xian
 */
public abstract class Computer {
    protected String serialNumber;
    protected String brand;
    protected String model;
    protected ComputerType type;

    // Constructor de la clase abstracta
    public Computer(String serialNumber, String brand, String model, ComputerType type) {
        this.serialNumber = serialNumber;
        this.brand = brand;
        this.model = model;
        this.type = type;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
    
    public ComputerType getType() {
        return type;
    }

    public void setType(ComputerType type) {
        this.type = type;
    }
    
    
}
