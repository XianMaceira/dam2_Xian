/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.aldComputerService;

/**
 *
 * @author maceira_barca_xian
 */
public class Laptop extends Computer{
    private String screenSizeInches;
    private String touchScreen;

    // Constructor de la clase Laptop
    public Laptop(String serialNumber, String brand, String model, ComputerType type, String screenSizeInches, String touchScreen) {
        super(serialNumber, brand, model, type);
        this.screenSizeInches = screenSizeInches;
        this.touchScreen = touchScreen;
    }
    
    public Laptop(String serialNumber, String brand, String model, ComputerType type) {
        super(serialNumber, brand, model, type);
        this.screenSizeInches = "";
        this.touchScreen = "";
    }

    public String getScreenSizeInches() {
        return screenSizeInches;
    }

    public void setScreenSizeInches(String screenSizeInches) {
        this.screenSizeInches = screenSizeInches;
    }

    public String isTouchScreen() {
        return touchScreen;
    }

    public void setTouchScreen(String touchScreen) {
        this.touchScreen = touchScreen;
    }
    
    
}
