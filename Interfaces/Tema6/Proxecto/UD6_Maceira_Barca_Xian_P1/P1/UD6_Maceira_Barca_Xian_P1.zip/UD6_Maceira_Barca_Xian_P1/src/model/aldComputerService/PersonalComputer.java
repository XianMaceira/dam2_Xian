/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.aldComputerService;

/**
 *
 * @author maceira_barca_xian
 */
public class PersonalComputer extends Computer {
    private String ramSizeGB;
    private String storageSizeGB;

    // Constructor de la clase PersonalComputer
    public PersonalComputer(String serialNumber, String brand, String model, ComputerType type, String ramSizeGB, String storageSizeGB) {
        super(serialNumber, brand, model, type);
        this.ramSizeGB = ramSizeGB;
        this.storageSizeGB = storageSizeGB;
    }
    
    public PersonalComputer(String serialNumber, String brand, String model, ComputerType type) {
        super(serialNumber, brand, model, type);
        this.ramSizeGB = "";
        this.storageSizeGB = "";
    }

    public String getRamSizeGB() {
        return ramSizeGB;
    }

    public void setRamSizeGB(String ramSizeGB) {
        this.ramSizeGB = ramSizeGB;
    }

    public String getStorageSizeGB() {
        return storageSizeGB;
    }

    public void setStorageSizeGB(String storageSizeGB) {
        this.storageSizeGB = storageSizeGB;
    }
    
    
}
