/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.aldComputerService;

/**
 *
 * @author maceira_barca_xian
 */
public class Server extends Computer{
    private String rackUnits;
    private String maximumConnections;

    // Constructor de la clase Server
    public Server(String serialNumber, String brand, String model, ComputerType type, String rackUnits, String maximumConnections) {
        super(serialNumber, brand, model, type);
        this.rackUnits = rackUnits;
        this.maximumConnections = maximumConnections;
    }
    
    public Server(String serialNumber, String brand, String model, ComputerType type) {
        super(serialNumber, brand, model, type);
        this.rackUnits = "";
        this.maximumConnections = "";
    }

    public String getRackUnits() {
        return rackUnits;
    }

    public void setRackUnits(String rackUnits) {
        this.rackUnits = rackUnits;
    }

    public String getMaximumConnections() {
        return maximumConnections;
    }

    public void setMaximumConnections(String maximumConnections) {
        this.maximumConnections = maximumConnections;
    }
    
    

}
