package com.example.box_column_row_practica

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.box_column_row_practica.ui.theme.Box_column_row_practicaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Box_column_row_practicaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MyTopBox()
                    MyBottomBox()
                    MyCenterBox()

                }
            }
        }
    }
}

@Composable
fun MyColumn() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.SpaceBetween
    ) {

    }
}


@Composable
fun MyTopBox() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.335f)
                .background(Color.Yellow),
            contentAlignment = Alignment.Center
        ) {

            Text(text = "Arriba")

        }


    }

}

@Composable
fun MyBottomBox() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.335f)
                .background(Color.Blue),
            contentAlignment = Alignment.Center
        ) {

            Text(text = "Abajo")

        }


    }

}

@Composable
fun MyCenterBox() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(0.33f)
                    .background(Color.Red),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "Izquierda")
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(0.33f)
                    .background(Color.Green),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "Derecha")
            }
        }
    }
}


@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Box_column_row_practicaTheme {
        MyTopBox()
        MyBottomBox()
        MyCenterBox()

    }
}