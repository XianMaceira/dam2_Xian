package com.example.constraintlayout

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ChainStyle
import androidx.constraintlayout.compose.ConstraintLayout

@Composable
@Preview
fun MyConstraintLayout() {
    ConstraintLayout(modifier = Modifier.fillMaxSize()) {

        val (boxRed, boxYellow, boxGreen, boxBlue) = createRefs()
        val topGuide = createGuidelineFromTop(0.2f)
        val startGuide = createGuidelineFromStart(0.2f)

        Box(modifier = Modifier
            .fillMaxWidth(1f)
            .fillMaxSize(0.35f)
            .background(Color.Yellow)
            .constrainAs(boxYellow) {
                top.linkTo(parent.top)
                start.linkTo(parent.start)
            },
        contentAlignment = Alignment.Center
        ) {
            Text(text = "Estoy arriba")

        }

        Box(modifier = Modifier
            .fillMaxWidth(0.5f)
            .fillMaxSize(0.35f)
            .background(Color.Red)
            .constrainAs(boxRed) {
                top.linkTo(boxYellow.bottom)
                start.linkTo(parent.start)
            },
            contentAlignment = Alignment.Center
        ) {
            Text(text = "Estoy Medio Izquierda")

        }

        Box(modifier = Modifier
            .fillMaxWidth(0.5f)
            .fillMaxSize(0.35f)
            .background(Color.Green)
            .constrainAs(boxGreen) {
                top.linkTo(boxYellow.bottom)
                start.linkTo(boxRed.end)
            },
            contentAlignment = Alignment.Center
        ) {
            Text(text = "Estoy Medio Derecha")

        }

        Box(modifier = Modifier
            .fillMaxWidth(1f)
            .fillMaxSize(0.35f)
            .background(Color.Blue)
            .constrainAs(boxBlue) {
                top.linkTo(boxRed.bottom)
                start.linkTo(parent.start)
            },
            contentAlignment = Alignment.Center
        ) {
            Text(text = "Estoy Abajo")

        }
    }
}
