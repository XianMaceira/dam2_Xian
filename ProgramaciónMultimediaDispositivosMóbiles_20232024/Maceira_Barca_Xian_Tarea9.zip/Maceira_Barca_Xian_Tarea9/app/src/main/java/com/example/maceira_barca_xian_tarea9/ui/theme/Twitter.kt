package com.example.maceira_barca_xian_tarea9.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.maceira_barca_xian_tarea9.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Twitter() {
    Scaffold(
        topBar = { MyTopAppBar() },
        floatingActionButton = { MyFloatingActionButton() },
        bottomBar = { MyBottomAppBar() }
    ) { contentPadding ->
        Box(modifier = Modifier.padding(contentPadding)) {
            MyDM()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyTopAppBar() {
    Column {
        CenterAlignedTopAppBar(
            title = { Text(text = "")},
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = Color.Black,
                navigationIconContentColor = Color.White,
                actionIconContentColor = Color.White
            ),
            actions = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_icon), 
                        contentDescription = "PFP",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .border(1.dp, Color.Black, CircleShape)
                        )
                    Text(text = "Messages",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(imageVector = Icons.Filled.Menu,
                        contentDescription = "Menu icon")
                }
            }
        )
        TextField(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black)
                .padding(10.dp, 5.dp)
                .border(1.dp, Color.Gray, RoundedCornerShape(90.dp)),
            leadingIcon = {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = "SearchBar Icon",
                )
            },
            value = "Search Direct Messages",
            colors = TextFieldDefaults.textFieldColors(
                textColor = Color.White,
                containerColor = Color.LightGray,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent
            ),
            shape = RoundedCornerShape(90.dp),
            onValueChange = {/* TODO */ },
            placeholder = {
                Text(text = "Search Direct Messages")
            }
        )
    }
}

@Composable
fun MyFloatingActionButton() {
    ExtendedFloatingActionButton(
        onClick = { /*TODO*/ },
        containerColor = Color.Blue,
        contentColor = Color.White,
        shape = CircleShape
    ) {
        Icon(
            imageVector = Icons.Filled.Add,
            contentDescription = "Add",
            modifier = Modifier.padding(0.dp, 25.dp)
        )
    }
}

@Composable
fun MyBottomAppBar() {
    var i by remember { mutableStateOf(0) }
    NavigationBar(
        containerColor = Color.Black,
        contentColor = Color.White
    ) {
        NavigationBarItem(
            selected = i == 0,
            onClick = { i = 0 },
            icon = {
                Icon(imageVector = Icons.Filled.Home, contentDescription = "Home")
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                unselectedIconColor = Color.White,
                unselectedTextColor = Color.White,
                indicatorColor = Color.Transparent
            )
        )
        NavigationBarItem(
            selected = i == 1,
            onClick = { i = 1 },
            icon = {
                Icon(imageVector = Icons.Filled.Search, contentDescription = "Search")
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                unselectedIconColor = Color.White,
                unselectedTextColor = Color.White,
                indicatorColor = Color.Transparent
            )
        )
        NavigationBarItem(
            selected = i == 2,
            onClick = { i = 2 },
            icon = {
                Icon(imageVector = Icons.Filled.Menu, contentDescription = "Voice")
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                unselectedIconColor = Color.White,
                unselectedTextColor = Color.White,
                indicatorColor = Color.Transparent
            )
        )
        NavigationBarItem(
            selected = i == 3,
            onClick = { i = 3 },
            icon = {
                Icon(imageVector = Icons.Filled.Notifications, contentDescription = "Notifications")
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                unselectedIconColor = Color.White,
                unselectedTextColor = Color.White,
                indicatorColor = Color.Transparent
            )
        )
        NavigationBarItem(
            selected = i == 4,
            onClick = { i = 4 },
            icon = {
                Icon(imageVector = Icons.Filled.Email, contentDescription = "DM")
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                unselectedIconColor = Color.White,
                unselectedTextColor = Color.White,
                indicatorColor = Color.Transparent
            )
        )
    }
}




@Composable
fun MyDM() {
    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier
                .background(Color.Black)
                .padding(5.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.alonso),
                contentDescription = "userDmIcon",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .padding(10.dp)
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(1.dp, Color.Black, CircleShape)
            )
            Column() {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Fernando Alonso",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Image(
                        painter = painterResource(id = R.drawable.twitter_verified_badge),
                        contentDescription = "Verified",
                        modifier = Modifier
                            .padding(2.dp, 0.dp)
                            .size(20.dp)
                    )
                    Text(
                        text = "alo_oficial · 12h",
                        fontWeight = FontWeight.Light,
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = "En 2024 te dedico la 33",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier.height(50.dp)
                )

            }
        }
        Row(
            modifier = Modifier
                .background(Color.Black)
                .padding(5.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.lm95),
                contentDescription = "userDmIcon",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .padding(10.dp)
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(1.dp, Color.Black, CircleShape)
            )
            Column() {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Lightning Mcqueen",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Image(
                        painter = painterResource(id = R.drawable.twitter_verified_badge),
                        contentDescription = "Verified",
                        modifier = Modifier
                            .padding(2.dp, 0.dp)
                            .size(20.dp)
                    )
                    Text(
                        text = "@lmcqueen95 · 2h",
                        fontWeight = FontWeight.Light,
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = "Kachooow",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier.height(50.dp)
                )

            }
        }

        Row(
            modifier = Modifier
                .background(Color.Black)
                .padding(5.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.msc),
                contentDescription = "userDmIcon",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .padding(10.dp)
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(1.dp, Color.Black, CircleShape)
            )
            Column() {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Schumacher",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Image(
                        painter = painterResource(id = R.drawable.twitter_verified_badge),
                        contentDescription = "Verified",
                        modifier = Modifier
                            .padding(2.dp, 0.dp)
                            .size(20.dp)
                    )
                    Text(
                        text = "@schumahcer · 19m",
                        fontWeight = FontWeight.Light,
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = "Joder vaya siestecita me acabo de pegar",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier.height(50.dp)
                )

            }
        }

        Row(
            modifier = Modifier
                .background(Color.Black)
                .padding(5.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.elbicho),
                contentDescription = "userDmIcon",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .padding(10.dp)
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(1.dp, Color.Black, CircleShape)
            )
            Column() {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Cristiano Ronaldo",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Image(
                        painter = painterResource(id = R.drawable.twitter_verified_badge),
                        contentDescription = "Verified",
                        modifier = Modifier
                            .padding(2.dp, 0.dp)
                            .size(20.dp)
                    )
                    Text(
                        text = "@Cristiano · 3h",
                        fontWeight = FontWeight.Light,
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = "Turkishh ArrusPuchuchuu Siuuuu",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier.height(50.dp)
                )

            }
        }

        Row(
            modifier = Modifier
                .background(Color.Black)
                .padding(5.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.lobato),
                contentDescription = "userDmIcon",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .padding(10.dp)
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(1.dp, Color.Black, CircleShape)
            )
            Column() {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Antonio Lobato",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Image(
                        painter = painterResource(id = R.drawable.twitter_verified_badge),
                        contentDescription = "Verified",
                        modifier = Modifier
                            .padding(2.dp, 0.dp)
                            .size(20.dp)
                    )
                    Text(
                        text = "@alobatof1 · 47m",
                        fontWeight = FontWeight.Light,
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = "Salida a Santa Devota?",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier.height(50.dp)
                )

            }
        }


        Row(
            modifier = Modifier
                .background(Color.Black)
                .padding(5.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.logan),
                contentDescription = "userDmIcon",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .padding(10.dp)
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(1.dp, Color.Black, CircleShape)
            )
            Column() {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Logan Sargeant",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Image(
                        painter = painterResource(id = R.drawable.twitter_verified_badge),
                        contentDescription = "Verified",
                        modifier = Modifier
                            .padding(2.dp, 0.dp)
                            .size(20.dp)
                    )
                    Text(
                        text = "@LoganSargeant · 1h",
                        fontWeight = FontWeight.Light,
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = "WTF IS A KILOMETER 🦅🦅🦅🦅🦅",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier.height(50.dp)
                )

            }
        }

        Row(
            modifier = Modifier
                .background(Color.Black)
                .padding(5.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.goatkerxa),
                contentDescription = "userDmIcon",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .padding(10.dp)
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(1.dp, Color.Black, CircleShape)
            )
            Column() {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "ikerxa27",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )

                    Text(
                        text = "@ikerxa27 · 5m",
                        fontWeight = FontWeight.Light,
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }
                Text(
                    text = "sube al tayer",
                    color = Color.Gray,
                    fontSize = 18.sp,
                    modifier = Modifier.height(50.dp)
                )

            }
        }

    }
}