# -*- coding: utf-8 -*-
# from odoo import http


# class AgendaXmb(http.Controller):
#     @http.route('/agenda_xmb/agenda_xmb', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/agenda_xmb/agenda_xmb/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('agenda_xmb.listing', {
#             'root': '/agenda_xmb/agenda_xmb',
#             'objects': http.request.env['agenda_xmb.agenda_xmb'].search([]),
#         })

#     @http.route('/agenda_xmb/agenda_xmb/objects/<model("agenda_xmb.agenda_xmb"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('agenda_xmb.object', {
#             'object': obj
#         })
