# -*- coding: utf-8 -*-

from odoo import models, fields, api


class agenda_xmb(models.Model):
    _name = 'agenda_xmb.agenda_xmb'
    _description = 'agenda_xmb.agenda_xmb'

    nombre = fields.Char(String='nombre')
    telefono = fields.Char(String='telefono')
#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
